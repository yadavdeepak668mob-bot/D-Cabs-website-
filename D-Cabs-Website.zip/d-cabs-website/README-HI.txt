D Cabs वेबसाइट — सेटअप
========================
यह वेबसाइट प्रोजेक्ट है, अभी अपने-आप इंटरनेट पर लाइव नहीं है।

फीचर:
- कस्टमर बुकिंग अनुरोध भेज सकता है और Booking ID पाता है।
- Admin PIN से आप बुकिंग देखते हैं।
- गाड़ी उपलब्ध हो तो स्वीकार करके एडवांस राशि तय कर सकते हैं।
- स्वीकार होने के बाद कस्टमर Booking ID से UPI payment request देखता है।
- UPI ID default: 9350566511@ibl
- कस्टमर भुगतान के बाद UTR/transaction reference भेजता है।
- आप अपने UPI ऐप/बैंक में भुगतान देखकर ही Admin Panel से Paid confirm करें।

चलाने के लिए:
1. Node.js 18+ इंस्टॉल करें।
2. इस फोल्डर में terminal खोलें और `npm install` चलाएँ।
3. `.env.example` की कॉपी `.env` नाम से बनाएँ।
4. `.env` में ADMIN_PIN को अपने निजी मजबूत PIN से बदलें।
5. `npm start` चलाएँ और http://localhost:3000 खोलें।

Deploy:
- यह Express/Node.js backend वाला प्रोजेक्ट है। केवल Netlify पर static upload करने से backend नहीं चलेगा।
- Render, Railway या VPS जैसे Node.js host पर deploy करें।
- Environment variables सेट करें: ADMIN_PIN, UPI_ID=9350566511@ibl, BUSINESS_NAME=D Cabs, PUBLIC_BASE_URL.
- ध्यान: यह starter JSON file में bookings रखता है। Production में database (PostgreSQL/Supabase), HTTPS, backups, rate limiting और privacy policy जोड़ें।
- Render जैसे hosts पर local file storage restart/deploy के बाद मिट सकता है; production में persistent database जरूर लगाएँ।

महत्वपूर्ण पेमेंट सीमा:
- UPI ID या UPI intent link अकेले भुगतान की पुष्टि नहीं करता। इस संस्करण में कस्टमर UTR भेजता है और आप अपने UPI ऐप/बैंक में वास्तविक राशि जाँचकर मैन्युअल रूप से Paid confirm करते हैं।
- अभी अपने-आप SMS/WhatsApp notification नहीं भेजे जाते। इसके लिए approved SMS/WhatsApp provider, credentials और संभवतः approved templates जोड़ने होंगे।
- ग्राहक को एडवांस राशि, cancellation/refund terms और support details साफ दिखाएँ। बिना पुष्टि के बुकिंग को Paid न मानें।
