require("dotenv").config();
const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
const DB = path.join(__dirname, "bookings.json");
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
function all(){try{return JSON.parse(fs.readFileSync(DB,"utf8"))}catch{return []}}
function save(rows){fs.writeFileSync(DB,JSON.stringify(rows,null,2))}
function admin(req,res,next){if(!process.env.ADMIN_PIN || req.headers["x-admin-pin"]!==process.env.ADMIN_PIN)return res.status(401).json({error:"Admin PIN गलत है"});next()}
function clean(v){return String(v||"").trim().slice(0,500)}
app.get("/api/config",(req,res)=>res.json({upiId:process.env.UPI_ID||"9350566511@ibl",businessName:process.env.BUSINESS_NAME||"D Cabs",phone:"9350566511"}));
app.post("/api/bookings",(req,res)=>{
 const b=req.body||{};
 const required=["name","phone","pickup","drop","date","time","carType"];
 if(required.some(k=>!clean(b[k])))return res.status(400).json({error:"सभी जरूरी जानकारी भरें।"});
 if(!/^[0-9+ ()-]{10,16}$/.test(clean(b.phone)))return res.status(400).json({error:"मोबाइल नंबर सही भरें।"});
 const id="DC"+Date.now().toString().slice(-8)+Math.floor(10+Math.random()*90);
 const row={id,name:clean(b.name),phone:clean(b.phone),pickup:clean(b.pickup),drop:clean(b.drop),date:clean(b.date),time:clean(b.time),carType:clean(b.carType),notes:clean(b.notes),status:"PENDING",paymentStatus:"WAITING_FOR_APPROVAL",createdAt:new Date().toISOString()};
 const rows=all();rows.unshift(row);save(rows);res.json({ok:true,id,message:"बुकिंग अनुरोध भेज दिया गया है। गाड़ी की उपलब्धता जाँचने के बाद एडमिन इसे स्वीकार करेगा।"});
});
app.get("/api/bookings/:id",(req,res)=>{
 const b=all().find(x=>x.id===req.params.id);if(!b)return res.status(404).json({error:"Booking ID नहीं मिली"});
 const {id,name,pickup,drop,date,time,carType,status,paymentStatus,advanceAmount,upiLink,utr,createdAt}=b;
 res.json({id,name,pickup,drop,date,time,carType,status,paymentStatus,advanceAmount,upiLink,utr,createdAt,
 message:status==="ACCEPTED"?"आपकी बुकिंग स्वीकार हो गई है। एडवांस पेमेंट करें।":status==="PAID"?"एडवांस पेमेंट एडमिन द्वारा सत्यापित है।":status==="REJECTED"?"इस समय गाड़ी उपलब्ध नहीं है।":status==="PAYMENT_REVIEW"?"पेमेंट रेफरेंस मिल गया है, सत्यापन बाकी है।":"बुकिंग की उपलब्धता जाँची जा रही है।"});
});
app.get("/api/admin/bookings",admin,(req,res)=>res.json(all()));
app.post("/api/admin/bookings/:id/accept",admin,(req,res)=>{
 const amount=Number(req.body&&req.body.amount);if(!Number.isFinite(amount)||amount<1||amount>100000)return res.status(400).json({error:"एडवांस राशि ₹1 से ₹1,00,000 के बीच रखें।"});
 const rows=all(),b=rows.find(x=>x.id===req.params.id);if(!b)return res.status(404).json({error:"बुकिंग नहीं मिली"});
 const upi=process.env.UPI_ID||"9350566511@ibl",name=process.env.BUSINESS_NAME||"D Cabs";
 const note=("D Cabs "+b.id).slice(0,80);
 b.status="ACCEPTED";b.paymentStatus="PAYMENT_REQUESTED";b.advanceAmount=amount;
 b.upiLink="upi://pay?pa="+encodeURIComponent(upi)+"&pn="+encodeURIComponent(name)+"&am="+encodeURIComponent(amount.toFixed(2))+"&cu=INR&tn="+encodeURIComponent(note);
 b.acceptedAt=new Date().toISOString();save(rows);
 res.json({ok:true,id:b.id,advanceAmount:amount,upiId:upi,upiLink:b.upiLink,message:"बुकिंग स्वीकार हुई। कस्टमर को Booking ID देकर स्टेटस पेज देखने को कहें।"});
});
app.post("/api/admin/bookings/:id/reject",admin,(req,res)=>{const rows=all(),b=rows.find(x=>x.id===req.params.id);if(!b)return res.status(404).json({error:"बुकिंग नहीं मिली"});b.status="REJECTED";save(rows);res.json({ok:true})});
app.post("/api/bookings/:id/payment-reference",(req,res)=>{
 const utr=clean(req.body&&req.body.utr);if(utr.length<6)return res.status(400).json({error:"UPI transaction reference/UTR सही भरें।"});
 const rows=all(),b=rows.find(x=>x.id===req.params.id);if(!b)return res.status(404).json({error:"बुकिंग नहीं मिली"});
 if(b.status!=="ACCEPTED")return res.status(400).json({error:"पहले एडमिन से बुकिंग स्वीकार करवाएँ।"});
 b.utr=utr;b.paymentStatus="PAYMENT_REVIEW";b.status="PAYMENT_REVIEW";b.referenceSubmittedAt=new Date().toISOString();save(rows);
 res.json({ok:true,message:"पेमेंट रेफरेंस भेज दिया गया है। एडमिन बैंक/UPI ऐप में भुगतान जाँचकर पुष्टि करेगा।"});
});
app.post("/api/admin/bookings/:id/verify-payment",admin,(req,res)=>{
 const rows=all(),b=rows.find(x=>x.id===req.params.id);if(!b)return res.status(404).json({error:"बुकिंग नहीं मिली"});
 if(!b.utr)return res.status(400).json({error:"कस्टमर का UTR/रेफरेंस अभी नहीं आया।"});
 b.status="PAID";b.paymentStatus="PAID";b.verifiedAt=new Date().toISOString();save(rows);res.json({ok:true,message:"पेमेंट को सत्यापित चिह्नित किया गया।"});
});
app.listen(PORT,()=>console.log("D Cabs website running on port "+PORT));
